package com.example.tictactoeproject;

import android.widget.Button;
import android.widget.TextView;

import java.io.Console;

public class GameLogic {

    private int[][] gameBoard;

    private String[] playerNames = {"Player 1", "computer"};

    private Button playAgainBTN;
    private TextView playerTurn;

    private int player = 1;

    private int score = 0;
    int bestScore = -1000;
    int depth = 0;
    int bestrow, bestcol;

    int score2;
    int bestScore2;

    GameLogic() {
        gameBoard = new int[3][3];
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 3; c++) {
                gameBoard[r][c] = 0;
            }
    }

    public int evaluateBoard() {

        for (int r = 0; r < 3; r++)
            if (gameBoard[r][0] == gameBoard[r][1] && gameBoard[r][0] == gameBoard[r][2] &&
                    gameBoard[r][0] != 0) {
                if (gameBoard[r][0] == 1)
                    return -10;
                else
                    return 10;
            }
        for (int c = 0; c < 3; c++)
            if (gameBoard[0][c] == gameBoard[1][c] && gameBoard[2][c] == gameBoard[0][c] &&
                    gameBoard[0][c] != 0) {
                if (gameBoard[0][c] == 1)
                    return -10;
                else
                    return 10;
            }
        if (gameBoard[0][0] == gameBoard[1][1] && gameBoard[0][0] == gameBoard[2][2] &&
                gameBoard[0][0] != 0) {
            if (gameBoard[0][0] == 1)
                return -10;
            else
                return 10;
        }
        if (gameBoard[2][0] == gameBoard[1][1] && gameBoard[2][0] == gameBoard[0][2] &&
                gameBoard[2][0] != 0) {
            if (gameBoard[2][0] == 1)
                return -10;
            else
                return 10;
        }
        return 0;
    }

    public void bestMove(){

        for (int r = 0; r<3; r++) {
            for (int c = 0; c < 3; c++) {
                if(gameBoard[r][c] == 0) {
                    gameBoard[r][c] = 2;
                    score = minimax(gameBoard, depth, false);
                    gameBoard[r][c] = 0;
                    if(score > bestScore) {
                        bestScore = score;
                        bestrow = r;
                        bestcol = c;
                    }
                }
            }
        }
        System.out.println(score);
        gameBoard[bestrow][bestcol] = 2;
        setPlayer(getPlayer()-1);
    }

    private int minimax(int[][] gameBoard, int depth, boolean isMaximizing){
        score2 = evaluateBoard();
        if(isMaximizing){
            bestScore2 = -1000;
            for (int r = 0; r<3; r++) {
                for (int c = 0; c < 3; c++) {
                    if(gameBoard[r][c] == 0) {
                        gameBoard[r][c] = 2;
                        score2 = minimax(gameBoard, depth + 1, false);
                        gameBoard[r][c] = 0;
                        if(score2 > bestScore2) {
                            bestScore2 = score2;
                        }
                    }
                }
            }
            return bestScore2;
        }else {
            bestScore2 = 1000;
            for (int r = 0; r<3; r++) {
                for (int c = 0; c < 3; c++) {
                    if(gameBoard[r][c] == 0) {
                        gameBoard[r][c] = 1;
                        score2 = minimax(gameBoard, depth + 1, true);
                        gameBoard[r][c] = 0;
                        if(score2 < bestScore2) {
                            bestScore2 = score2;
                        }
                    }
                }
            }
            return bestScore2;
        }
    }

    public boolean updateGameBoard(int row, int col){
        if(gameBoard[row-1][col-1] == 0){
            gameBoard[row-1][col-1] = player;

            return true;
        }
        else {
            return false;
        }
    }

    public boolean winnerCheck() {
        boolean isWinner = false;
        for (int r = 0; r < 3; r++)
            if (gameBoard[r][0] == gameBoard[r][1] && gameBoard[r][0] == gameBoard[r][2] &&
                    gameBoard[r][0] != 0) {
                isWinner = true;
            }
        for (int c = 0; c < 3; c++)
            if (gameBoard[0][c] == gameBoard[1][c] && gameBoard[2][c] == gameBoard[0][c] &&
                    gameBoard[0][c] != 0) {
                isWinner = true;
            }
        if(gameBoard[0][0] == gameBoard[1][1] && gameBoard[0][0] == gameBoard[2][2] &&
                gameBoard[0][0] != 0){
            isWinner = true;
        }
        if(gameBoard[2][0] == gameBoard[1][1] && gameBoard[2][0] == gameBoard[0][2] &&
                gameBoard[2][0] != 0){
            isWinner = true;
        }

        int boardFilled = 0;
        for (int r = 0; r<3; r++)
            for (int c = 0; c<3; c++){
                if(gameBoard[r][c] != 0)
                    boardFilled += 1;
            }

        if(isWinner){
            playerTurn.setText((playerNames[player-1] + " Won!"));
            return true;
        }
        else if(boardFilled == 9){
            playerTurn.setText("Tie Game!");
            return true;

        }
        else {
            return false;
        }
    }

    public void resetGame(){
        for (int r = 0; r<3; r++) {
            for (int c = 0; c < 3; c++) {
                gameBoard[r][c] = 0;
            }
        }
        player = 1;
    }

    public int[][] getGameBoard(){
        return gameBoard;
    }

    public void setPlayer(int player) {
        this.player = player;
    }

    public int getPlayer() {
        return player;
    }

    public void setPlayAgainBTN(Button playAgainBTN) {
        this.playAgainBTN = playAgainBTN;
    }

    public void setPlayerTurn(TextView playerTurn) {
        this.playerTurn = playerTurn;
    }
}
